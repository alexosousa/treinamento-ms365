Scripts

Add Dominio

#como conecta no tenant
connect-msolservice

#Como criar um dominio 
New-MsolDomain -Name contoso.com.br
New-MsolDomain –Authentication Managed –Name contoso.com.br

#Consultar dominio
Get-MsolDomain
Get-MsolDomain -Status Verified

Get-MsolDomainVerificationDns –DomainName contoso.com.br –Mode DnsTxtRecord

Confirm-MsolEmailVerifiedDomain -DomainName contoso.com.br

Confirm-MsolDomain -DomainName contoso.com.br -ForceTakeover Force 

nslookup -type=TXT contoso.com.br 8.8.8.8
nslookup -type=MX contoso.com.br 8.8.8.8

Remove-MsolDomain -DomainName contoso.com.br -Force

https://www.digwebinterface.com/?hostnames=gmgb.com.br


&type=TXT&useresolver=8.8.4.4&ns=auth&nameservers=

Exchange Online
MX Record contoso-com-br.mail.protection.outlook.com (priority 0)
Autodiscover autodiscover.outlook.com (CNAME)
Msoid clientconfig.microsoftonline-p.net (CNAME)
TXT v=spf1 include:spf.protection.outlook.com –all

Teams
Sip sipdir.online.lync.com (CNAME)
Lyncdiscover webdir.online.lync.com (CNAME)

Service, Port, Weight, Priority, Target
_sip _tls 443 1 100 sipdir.online.lync.com
_sipfederationtls _tcp 5061 1 100 sipfed.online.lync.com

links
-Dominio
https://docs.microsoft.com/en-us/powershell/module/msonline/get-msoldomain?view=azureadps-1.0

Usuarios
connect-msolservice
Get-MsolUser
Get-MsolAccountSku
#usuarios bloqueados
Get-MsolUser -All | Where {$_.BlockCredential -eq $True} | Select DisplayName,UserPrincipalName
Get-MsolUser -all | select DisplayName,Department, Licenses | Where-Object {$_.Licenses.AccountSkuID -eq "crefazmaringa:EXCHANGESTANDARD" }
Get-MsolUser -All | Where-Object { $_.isLicensed -eq "TRUE" }
Get-MsolUser -UnlicensedUsersOnly
Get-MsolUser | Where {$_.UsageLocation -eq $Null}
Get-MsolUser | Select ObjectID

Get-MsolGroup
Remove-MsolGroupMember








