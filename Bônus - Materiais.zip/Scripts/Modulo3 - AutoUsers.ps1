﻿#Importe Modulo
Import-Module ActiveDirectory
#Senhas
$secpass = Read-Host "Password" -AsSecureString
#Usuários
New-ADUser -Name "Thiago Alves" -SamAccountName thiago.alves -UserPrincipalName "thiago.alves@matriz365.local" -department "RH" -AccountPassword $secpass -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -Enabled:$true
New-ADUser -Name "Thiago Moraes" -SamAccountName thiago.moraes -UserPrincipalName "thiago.moraes@matriz365.local" -department "RH" -AccountPassword $secpass -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -Enabled:$true
New-ADUser -Name "Jessica Simoes" -SamAccountName jessica.simoes -UserPrincipalName "jessica.simoes@matriz365.local" -department "Administrativo" -AccountPassword $secpass -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -Enabled:$true
New-ADUser -Name "Danilo Hora" -SamAccountName danilo.hora -UserPrincipalName "danilo.hora@matriz365.local" -department "Financeiro"-AccountPassword $secpass -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -Enabled:$true
New-ADUser -Name "Daniel Macedo" -SamAccountName daniel.macedo -UserPrincipalName "daniel.macedo@matriz365.local" -department "TI"-AccountPassword $secpass -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -Enabled:$true
New-ADUser -Name "Erick Hanada" -SamAccountName erick.hanada -UserPrincipalName "erick.hanada@matriz365.local" -department "TI" -AccountPassword $secpass -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -Enabled:$true
New-ADUser -Name "Jose Xavier" -SamAccountName jose.xavier -UserPrincipalName "jose.xavier@matriz365.local" -department "Financeiro" -AccountPassword $secpass -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -Enabled:$true
#Grupos
New-ADGroup -Name "RH" -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -GroupCategory Security -GroupScope Global 
New-ADGroup -Name "Administrativo" -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -GroupCategory Security -GroupScope Global 
New-ADGroup -Name "Financeiro" -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -GroupCategory Security -GroupScope Global 
New-ADGroup -Name "TI" -Path "OU=Users,OU=Matriz365,DC=matriz365,DC=local" -GroupCategory Security -GroupScope Global 
#Permissões
Add-AdGroupMember -Identity RH -Members thiago.alves, thiago.moraes
Add-AdGroupMember -Identity Administrativo -Members jessica.simoes
Add-AdGroupMember -Identity Financeiro -Members danilo.hora, jose.xavier
Add-AdGroupMember -Identity TI -Members daniel.macedo, erick.hanada