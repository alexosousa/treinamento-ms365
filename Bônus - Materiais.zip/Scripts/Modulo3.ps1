#AD Connect Cloud Sync

## Install Cliente
https://docs.microsoft.com/pt-br/azure/active-directory/cloud-sync/how-to-configure
https://docs.microsoft.com/en-us/troubleshoot/azure/active-directory/azure-ad-hybrid-sync-no-privileges-install-msi
https://docs.microsoft.com/en-us/troubleshoot/azure/active-directory/azure-ad-hybrid-sync-unable-create-gmsa-kds-domain-controller
https://docs.microsoft.com/en-us/azure/active-directory/authentication/tutorial-enable-cloud-sync-sspr-writeback#configure-azure-ad-connect-cloud-sync-service-account-permissions

#link Doc diferenças
https://docs.microsoft.com/pt-br/azure/active-directory/cloud-sync/what-is-cloud-sync?toc=https%3A%2F%2Fdocs.microsoft.com%2Fen-us%2Fazure%2Factive-directory%2Fcloud-sync%2Ftoc.json&bc=https%3A%2F%2Fdocs.microsoft.com%2Fen-us%2Fazure%2Fbread%2Ftoc.json
https://docs.microsoft.com/pt-br/azure/active-directory/hybrid/choose-ad-authn

# links Domínio
https://docs.microsoft.com/pt-br/azure/active-directory/hybrid/whatis-hybrid-identity
https://docs.microsoft.com/pt-br/azure/active-directory/hybrid/choose-ad-authn
https://docs.microsoft.com/pt-br/azure/active-directory/hybrid/whatis-hybrid-identity?toc=https%3A%2F%2Fdocs.microsoft.com%2Fpt-br%2Fazure%2Factive-directory%2Fhybrid%2Ftoc.json&bc=https%3A%2F%2Fdocs.microsoft.com%2Fpt-br%2Fazure%2Fbread%2Ftoc.json
https://docs.microsoft.com/pt-br/microsoft-365/enterprise/m365-enterprise-test-lab-guides?view=o365-worldwide
https://docs.microsoft.com/pt-br/azure/active-directory/authentication/
https://docs.microsoft.com/pt-br/azure/storage/files/storage-files-identity-auth-active-directory-enable

## ADD

# Principal

$Users=Get-ADUser -SearchBase "OU=Users AD Connect,OU=.Lab 365,DC=lab365,DC=local" -filter * | Select SamAccountName, DistinguishedName
$NewEmail="@matriz365.cf"

Foreach ($User in $Users) { 

$NewSMTP= 'SMTP:'+$User.SamAccountName+$NewEmail

Set-ADUser -Identity $user.DistinguishedName -Add @{ProxyAddresses= $NewSMTP} -Server lab-365-ad-01.lab365.local
                          }
# Alias

$Users=Get-ADUser -SearchBase "OU=Users AD Connect,OU=.Lab 365,DC=lab365,DC=local" -filter * | Select SamAccountName, DistinguishedName
$NewEmail="@filial365.cf"

Foreach ($User in $Users) { 

$NewSMTP= 'smtp:'+$User.SamAccountName+$NewEmail

Set-ADUser -Identity $user.DistinguishedName -Add @{ProxyAddresses= $NewSMTP} -Server lab-365-ad-01.lab365.local
                          }
						  
## Remove

$Users=Get-ADUser -SearchBase "OU=Users AD Connect,OU=.Lab 365,DC=lab365,DC=local" -filter * | Select SamAccountName, DistinguishedName
$OldEmail="@filial365.cf"

Foreach ($User in $Users) { 

$OldSMTP= 'smtp:'+$User.SamAccountName+$OldEmail

Set-ADUser -Identity $user.DistinguishedName -Remove @{ProxyAddresses= $OldSMTP} -Server SRVDC01.lab365.local

} 

#Disable Sincronismo
Import-Module MSOnline
Connect-MsolService
(Get-MSOLCompanyInformation).DirectorySynchronizationEnabled
Set-MsolDirSyncEnabled –EnableDirSync $false