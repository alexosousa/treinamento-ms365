#Conecta Exchange Online

Install-Module ExchangeOnlineManagement -AllowClobber
Import-Module ExchangeOnlineManagement
Connect-ExchangeOnline

#consulta migracao
   
Test-MigrationServerAvailability -IMAP -RemoteServer imap.hostinger.com -Port 993 -Security Ssl

Get-MigrationBatch -Identity IMAP01 | Format-List

Get-MigrationBatch -Identity IMAP01 | Format-List Status

Get-MigrationUser | Get-MigrationUserStatistics


#Antigo

Get-Mailbox
Get-Mailbox -ResultSize 20
Get-mailbox -Identity alex.sousa@matriz365.cf | fl
Get-Mailbox –RecipientType 'UserMailbox' | Get-MailboxStatistics | Sort-Object LastLogonTime | Where {$_.LastLogonTime –lt ([DateTime]::Now).AddDays(-1) } | Format-Table DisplayName, LastLogonTime # 1 dia
Get-MailTrafficATPReport # Inbound and Outbound
Get-MailboxFolderPermission -Identity alex.sousa@matriz365.cf | fl
Get-Recipient -Identity alex.sousa@matriz365.cf | fl
Get-RecipientPermission -Identity alex.sousa@matriz365.cf | fl   

#Novo

Get-EXOMailbox   
Get-EXOMailboxFolderPermission -Identity alex.sousa@matriz365.cf | fl
Get-EXOMailboxPermission -Identity alex.sousa@matriz365.cf | fl
Get-EXOMailboxStatistics -Identity alex.sousa@matriz365.cf | fl 
Get-EXORecipient -Identity alex.sousa@matriz365.cf | fl
Get-EXORecipientPermission -Identity alex.sousa@matriz365.cf | fl

#Criar Mailbox Compartilhada
New-Mailbox -Name "Mailbox Compartilhada" -Alias mbcompartilhada –Shared -PrimarySmtpAddress mbcompartilhada@matriz365.cf
Get-Mailbox -Filter {recipienttypedetails -eq "SharedMailbox"}
Remove-Mailbox "Mailbox Compartilhada" 

#Criar Mailbox 
New-Mailbox -Alias Mailbox -Name Mailbox -FirstName Mailbox -LastName Teste -DisplayName "Mailbox Teste" -MicrosoftOnlineServicesID mbteste@matriz365.cf -Password (ConvertTo-SecureString -String 'P@ssw0rd' -AsPlainText -Force) -ResetPasswordOnNextLogon $true
Get-Mailbox
Remove-Mailbox "Mailbox" 
Get-Mailbox

#Archive
Enable-Mailbox -Identity alex.sousa@matriz365.cf -Archive
Get-Mailbox -Archive
Get-Mailbox | Enable-Mailbox -Archive
Get-Mailbox | Disable-Mailbox -Archive

#disconect
Remove-PSSession $exchangeSession

links
-Exchange
https://docs.microsoft.com/pt-br/powershell/exchange/?view=exchange-ps
https://docs.microsoft.com/pt-br/office365/servicedescriptions/exchange-online-service-description/exchange-online-limits
https://docs.microsoft.com/pt-br/microsoft-365/compliance/unlimited-archiving?view=o365-worldwide
https://docs.microsoft.com/pt-br/office365/servicedescriptions/exchange-online-archiving-service-description/exchange-online-archiving-service-description#unlimited-archive-storage-quota
https://docs.microsoft.com/da-dk/exchange/troubleshoot/configure-mailboxes/set-automatic-replies
https://docs.microsoft.com/pt-br/microsoft-365/compliance/use-network-upload-to-import-pst-files?view=o365-worldwide
https://dicasdeinfra.com.br/13-comandos-obrigatorios-do-microsoft-365-powershell/#
https://www.codetwo.com/blog/mailbox-backup-options-across-available-office-365-plans/


https://docs.microsoft.com/pt-br/exchange/mailbox-migration/migrating-imap-mailboxes/migrating-imap-mailboxes
https://docs.microsoft.com/pt-br/microsoft-365/enterprise/use-powershell-to-perform-an-imap-migration-to-microsoft-365?view=o365-worldwide
https://docs.microsoft.com/pt-br/Exchange/mailbox-migration/migrating-imap-mailboxes/migrating-imap-mailboxes?redirectSourcePath=%252farticle%252fWhat-you-need-to-know-about-migrating-your-IMAP-mailboxes-to-Office-365-3fe19996-29bc-4879-aab9-5a622b2f1481
https://docs.microsoft.com/pt-br/exchange/mailbox-migration/office-365-migration-best-practices