#SharePoint

#Install Module 
Get-Module -Name Microsoft.Online.SharePoint.PowerShell -ListAvailable | Select Name,Version
Install-Module -Name Microsoft.Online.SharePoint.PowerShell

#Connect Module 
$adminUPN="admin@matriz36501.onmicrosoft.com"
$orgName="matriz36501"
$userCredential = Get-Credential -UserName $adminUPN -Message "Pow"
Connect-SPOService -Url https://$orgName-admin.sharepoint.com -Credential $userCredential

#Novo Site
New-SPOSite -Url "https://matriz36501.sharepoint.com/sites/NewSite01" -Owner "admin@matriz36501.onmicrosoft.com" -StorageQuota "100" -Title "NewSite01"

#Consultar Sites
Get-SPOSite
Get-SPOSite -Identity https://matriz36501.sharepoint.com -DisableSharingForNonOwnersStatus

#Verificação de Renomeação Site
#Execute o seguinte comando para verificar se o endereço do site pode ser alterado:
Start-SPOSiteRename -Identity https://matriz36501.sharepoint.com/sites/NewSite00 -NewSiteUrl https://matriz36501.sharepoint.com/sites/newsite01  -ValidationOnly

#Renomeação Site
#Execute o seguinte comando para alterar o endereço do site:
Start-SPOSiteRename -Identity https://matriz36501.sharepoint.com/sites/NewSite00 -NewSiteUrl https://matriz36501.sharepoint.com/sites/NewSite01 

#Remove Sites
Remove-SPOSite -Identity https://matriz36501.sharepoint.com/sites/NewSite01

#Retores Sites
Restore-SPODeletedSite -Identity https://matriz36501.sharepoint.com/sites/NewSite01